<?php
declare(strict_types=1);
require __DIR__ . '/lib.php';
start_secure_session();
$_SESSION['csrf'] = bin2hex(random_bytes(32));
$_SESSION['csrf_t'] = time();
json_out(['token' => $_SESSION['csrf']]);

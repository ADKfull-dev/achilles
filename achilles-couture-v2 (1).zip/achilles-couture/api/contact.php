<?php
declare(strict_types=1);
require __DIR__ . '/lib.php';
if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') json_out(['ok' => false, 'message' => 'Méthode non autorisée.'], 405);
start_secure_session();
$origin = $_SERVER['HTTP_ORIGIN'] ?? '';
if ($origin !== '' && parse_url($origin, PHP_URL_HOST) !== ($_SERVER['HTTP_HOST'] ?? '') && parse_url($origin, PHP_URL_HOST) . ':' . (parse_url($origin, PHP_URL_PORT) ?? '') !== ($_SERVER['HTTP_HOST'] ?? ''))
    json_out(['ok' => false, 'message' => 'Origine refusée.'], 403);
$tok = (string)($_POST['csrf'] ?? '');
if (empty($_SESSION['csrf']) || !hash_equals($_SESSION['csrf'], $tok)) json_out(['ok' => false, 'message' => 'Session expirée, rechargez la page.'], 403);
if (!empty($_POST['website'])) json_out(['ok' => true]);                                  // anti-spam : champ piège rempli par les robots
if (time() - (int)($_SESSION['csrf_t'] ?? 0) < 3) json_out(['ok' => false, 'message' => 'Envoi trop rapide, réessayez.'], 429);
$_SESSION['sent'] = array_filter($_SESSION['sent'] ?? [], fn($t) => $t > time() - 600);
if (count($_SESSION['sent']) >= 3) json_out(['ok' => false, 'message' => 'Trop de demandes, réessayez plus tard.'], 429);
$clean = fn(string $k, int $max, bool $multi = false): string => mb_substr(trim(preg_replace($multi ? '/[^\P{C}\n]/u' : '/\p{C}/u', '', (string)($_POST[$k] ?? ''))), 0, $max);
$nom = $clean('nom', 80); $tel = $clean('tel', 20); $type = $clean('type', 40); $ref = $clean('ref', 80); $rdv = $clean('rdv', 10); $besoin = $clean('besoin', 2000, true);
$types = ['Costume', 'Tenue en pagne', 'Tenue traditionnelle', 'Tenue de cérémonie', 'Création personnalisée', 'Retouche ou ajustement', 'Autre'];
$err = [];
if (mb_strlen($nom) < 2) $err['nom'] = 'Nom requis.';
if (!preg_match('/^\+?[0-9 ().-]{8,18}$/', $tel)) $err['tel'] = 'Téléphone invalide.';
if (!in_array($type, $types, true)) $err['type'] = 'Type invalide.';
if (mb_strlen($besoin) < 10) $err['besoin'] = 'Description trop courte.';
if ($rdv !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $rdv)) $err['rdv'] = 'Date invalide.';
if ($err) json_out(['ok' => false, 'message' => 'Champs invalides.', 'errors' => $err], 422);
$cfg = require __DIR__ . '/config.php';
if (empty($cfg['to']) || empty($cfg['from'])) json_out(['ok' => false, 'message' => 'not_configured'], 503);
$body = "Nom : $nom\nTéléphone : $tel\nVêtement : $type\nCréation de référence : " . ($ref ?: '-') . "\nRendez-vous souhaité : " . ($rdv ?: '-') . "\n\n$besoin\n";
$ok = mail($cfg['to'], mb_encode_mimeheader("Demande de confection — $nom", 'UTF-8'), $body, ['From' => $cfg['from'], 'Content-Type' => 'text/plain; charset=UTF-8']);
if (!$ok) json_out(['ok' => false, 'message' => 'Envoi impossible pour le moment.'], 500);
$_SESSION['sent'][] = time(); unset($_SESSION['csrf']);
json_out(['ok' => true]);

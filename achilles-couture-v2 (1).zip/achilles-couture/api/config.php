<?php
// À configurer lorsque l'hébergement est choisi. Tant que 'to' est vide, le formulaire répond « non configuré ».
return [
    'to'   => '',  // adresse qui reçoit les demandes (à renseigner)
    'from' => '',  // expéditeur sur votre domaine, ex. no-reply@votre-domaine.com (à renseigner)
];

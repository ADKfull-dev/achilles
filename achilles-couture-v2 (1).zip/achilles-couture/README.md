# Achille’s Couture — site web (ATLANTIK WEB)
- `python3 tools/build.py` régénère les pages depuis `src/` (en-tête/pied de page : `src/partials/`).
- Contenus, numéro WhatsApp, messages, créations et photos : `data/site.js`.
- Photos : déposer les originaux dans `photos-originales/` (nom = identifiant), `pip install pillow`, `python3 tools/optimize.py`, puis renseigner `file` dans `data/site.js`.
- Formulaire : renseigner `to` et `from` dans `api/config.php` (hébergement PHP avec `mail()` ou SMTP requis). Sans cela, le visiteur est invité à utiliser WhatsApp.

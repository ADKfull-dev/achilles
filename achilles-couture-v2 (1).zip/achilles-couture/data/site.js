/* Configuration unique du site : numéro, messages WhatsApp, photos, créations.
   Photo réelle : déposer l'original dans /photos-originales (nom = identifiant), lancer tools/optimize.py,
   puis mettre file:"identifiant" (et un vrai texte alternatif). publie:false masque une création. */
window.SITE = {
  wa: "2290197277159",
  msgs: {
    general:   "Bonjour Achille’s Couture, je souhaite obtenir des renseignements.",
    mesure:    "Bonjour Achille’s Couture, je souhaite obtenir des renseignements concernant une confection sur mesure.",
    costumes:  "Bonjour Achille’s Couture, je souhaite obtenir des renseignements concernant un costume sur mesure.",
    pagnes:    "Bonjour Achille’s Couture, je souhaite obtenir des renseignements concernant une tenue en pagne.",
    perso:     "Bonjour Achille’s Couture, je souhaite obtenir des renseignements concernant une création personnalisée.",
    retouches: "Bonjour Achille’s Couture, je souhaite obtenir des renseignements concernant une retouche ou un ajustement.",
    rdv:       "Bonjour Achille’s Couture, je souhaite prendre rendez-vous."
  },
  creation: nom => `Bonjour Achille’s Couture, la création « ${nom} » m’intéresse. Pouvez-vous me renseigner ?`,
  photos: {
    "hero-01": { file: "", alt: "Photographie principale de la maison", pos: "50% 30%" },
    "hero-02": { file: "", alt: "Photographie de l’autre univers de la maison", pos: "50% 30%" },
    "costumes-01": { file: "", alt: "Costume sur mesure", pos: "50% 25%" },
    "pagnes-01": { file: "", alt: "Tenue en pagne", pos: "50% 25%" },
    "pagnes-02": { file: "", alt: "Détail de pagne", pos: "50% 25%" },
    "cta-01": { file: "", alt: "Ambiance de l’atelier", pos: "50% 30%" },
    "detail-01": { file: "", alt: "Détail de tissu", pos: "50% 50%" },
    "detail-02": { file: "", alt: "Détail de coutures", pos: "50% 50%" },
    "detail-03": { file: "", alt: "Détail de finitions", pos: "50% 50%" }
  },
  /* Noms et descriptions PROVISOIRES, à confirmer avec Achille. cats : pagnes | costumes | ceremonies */
  creations: [
    { id: "costume-classique", nom: "Costume classique", univers: "costumes", cats: ["costumes"], r: "4/5", feat: true, desc: "Costume classique confectionné sur mesure.", file: "", alt: "Costume classique" },
    { id: "costume-moderne", nom: "Costume moderne", univers: "costumes", cats: ["costumes"], r: "1/1", desc: "Costume à la coupe moderne, sur mesure.", file: "", alt: "Costume moderne" },
    { id: "ensemble-mesure", nom: "Ensemble sur mesure", univers: "costumes", cats: ["costumes"], r: "3/4", desc: "Ensemble confectionné selon vos mesures.", file: "", alt: "Ensemble sur mesure" },
    { id: "ceremonie-homme", nom: "Tenue de cérémonie (homme)", univers: "costumes", cats: ["costumes", "ceremonies"], r: "4/5", desc: "Tenue masculine pour les grandes occasions.", file: "", alt: "Tenue de cérémonie pour homme" },
    { id: "tenue-traditionnelle", nom: "Tenue traditionnelle", univers: "pagnes", cats: ["pagnes"], r: "3/4", feat: true, desc: "Tenue traditionnelle africaine en pagne.", file: "", alt: "Tenue traditionnelle en pagne" },
    { id: "robe-elegante", nom: "Robe élégante", univers: "pagnes", cats: ["pagnes"], r: "4/5", feat: true, desc: "Robe élégante confectionnée en pagne.", file: "", alt: "Robe élégante en pagne" },
    { id: "ensemble-africain", nom: "Ensemble africain moderne", univers: "pagnes", cats: ["pagnes"], r: "1/1", desc: "Ensemble africain à l’allure contemporaine.", file: "", alt: "Ensemble africain moderne" },
    { id: "ceremonie-pagne", nom: "Tenue de cérémonie en pagne", univers: "pagnes", cats: ["pagnes", "ceremonies"], r: "3/4", desc: "Tenue en pagne pour les cérémonies.", file: "", alt: "Tenue de cérémonie en pagne" }
  ]
};

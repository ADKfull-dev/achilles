"""Assemble les pages HTML : python3 tools/build.py
Les contenus sont dans src/*.html, l'en-tête et le pied de page dans src/partials/."""
import pathlib, re
R = pathlib.Path(__file__).resolve().parent.parent
D = "Maison de couture à Abomey-Calavi : tenues traditionnelles africaines, créations en pagne, costumes sur mesure et retouches."
PAGES = {  # page: (titre, description, css supplémentaire, scripts supplémentaires)
 "index": ("Achille’s Couture — L’élégance dans chaque couture | Abomey-Calavi, Bénin", D, False, []),
 "collections": ("Nos collections — Achille’s Couture", "Costumes et créations en pagne : découvrez les deux univers de la maison.", True, ["collections"]),
 "services": ("Nos services — Achille’s Couture", "Confection sur mesure, création personnalisée, costumes, pagne, retouches.", True, []),
 "savoir-faire": ("Notre savoir-faire — Achille’s Couture", "Le fil et la coupe : la philosophie et le processus de confection de la maison.", True, []),
 "galerie": ("Galerie — Achille’s Couture", "Galerie photographique des créations : pagnes, costumes, cérémonies.", True, ["gallery"]),
 "contact": ("Contact et commandes — Achille’s Couture", "Demande de confection, rendez-vous et WhatsApp : Achille’s Couture, Abomey-Calavi.", True, ["contact"]),
}
head = lambda t, d, css: f'''<!DOCTYPE html>
<html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title>{t}</title><meta name="description" content="{d}">
<link rel="icon" href="assets/img/logo.svg"><link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,500;0,600;1,500&family=Jost:wght@400;500&display=swap">
<link rel="stylesheet" href="assets/css/style.css">{'<link rel="stylesheet" href="assets/css/pages.css">' if css else ''}</head>
<body><a class="skip" href="#main">Aller au contenu</a>
'''
H = (R/"src/partials/header.html").read_text(); F = (R/"src/partials/footer.html").read_text()
for name, (t, d, css, js) in PAGES.items():
    h = H.replace(f'href="{name}.html"', f'href="{name}.html" aria-current="page"', 1) if name != "index" else H
    scripts = "".join(f'<script src="assets/js/{j}.js" defer></script>' for j in js)
    out = head(t, d, css) + h + (R/f"src/{name}.html").read_text() + F + '\n<script src="data/site.js"></script><script src="assets/js/main.js" defer></script>' + scripts + "</body></html>\n"
    (R/f"{name}.html").write_text(out)
    print("OK", name + ".html")

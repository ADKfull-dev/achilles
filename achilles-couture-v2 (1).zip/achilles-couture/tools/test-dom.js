// Tests DOM (jsdom) : NODE_PATH=<dossier node_modules> node tools/test-dom.js — vérifie le comportement JS, pas le rendu visuel.
const { JSDOM, VirtualConsole } = require("jsdom"), path = require("path"), fs = require("fs");
const R = path.resolve(__dirname, ".."); let fail = 0;
const ok = (c, m) => { console.log((c ? "PASS " : "FAIL ") + m); if (!c) fail++; };
const load = (page, opts = {}) => new Promise(res => {
  const errs = [], vc = new VirtualConsole(); const keep = m => !/googleapis|gstatic/.test(m); vc.on("jsdomError", e => keep(e.message) && errs.push(e.message)); vc.on("error", e => keep(String(e)) && errs.push(String(e)));
  JSDOM.fromURL("http://127.0.0.1:8765/" + page + (opts.q || ""), { runScripts: "dangerously", resources: "usable", pretendToBeVisual: true, virtualConsole: vc,
    beforeParse(w) { w.IntersectionObserver = class { observe() {} unobserve() {} }; w.matchMedia = () => ({ matches: true });
      w.HTMLDialogElement.prototype.showModal = function () { this.setAttribute("open", ""); }; w.HTMLDialogElement.prototype.close = function () { this.removeAttribute("open"); };
      w.opened = []; w.open = (u) => w.opened.push(u); w.fetch = opts.fetch || (() => Promise.reject(new Error("no php")));
      w.scrollTo = () => {}; if (opts.hash) w.location.hash = opts.hash; } })
    .then(d => d.window.addEventListener("load", () => setTimeout(() => res({ w: d.window, d: d.window.document, errs }), 50)));
});
const sleep0 = 0; const tick = ms => new Promise(r => setTimeout(r, ms));
(async () => {
  const pages = ["index", "collections", "services", "savoir-faire", "galerie", "contact"];
  for (const p of pages) {
    const { d, errs } = await load(p + ".html"); ok(errs.length === 0, `${p}: aucune erreur JS ${errs[0] || ""}`);
    ok(d.querySelectorAll("header.site-header, footer").length === 2, `${p}: header et footer présents`);
    ok([...d.querySelectorAll("[data-wa]")].every(a => a.href.startsWith("https://wa.me/2290197277159?text=")), `${p}: liens WhatsApp valides`);
    ok(!d.querySelector(`.nav a[aria-current]`) === (p === "index"), `${p}: lien actif du menu`);
    const imgs = [...d.querySelectorAll("img")]; ok(imgs.every(i => i.hasAttribute("alt")), `${p}: images avec alt`);
    ok([...d.querySelectorAll(".ph:not(.has-img)[data-photo]")].every(e => e.getAttribute("aria-label")), `${p}: emplacements photo avec texte alternatif`);
    d.querySelectorAll("a[href]").forEach(a => { const h = a.getAttribute("href"); if (/^(https?:|tel:|#$)/.test(h)) return;
      const [f, id] = h.split("#"); if (f && !h.startsWith("#") && !fs.existsSync(path.join(R, f.split("?")[0]))) ok(false, `${p}: lien cassé ${h}`);
      if (id && !f && !d.getElementById(id)) ok(false, `${p}: ancre manquante ${h}`); });
  }
  let { d } = await load("index.html"); ok(d.querySelectorAll("#sel .tile").length === 3, "accueil: 3 créations en sélection");
  const w0 = (await load("index.html")), btn = w0.d.querySelector(".menu-btn"); btn.style.display = "block"; /* le simulateur applique le CSS bureau */ btn.click();
  const links = [...w0.d.querySelectorAll("#menu a")]; ok(w0.d.activeElement === links[0], "menu mobile: focus sur le premier lien à l'ouverture");
  links.at(-1).focus(); links.at(-1).dispatchEvent(new w0.w.KeyboardEvent("keydown", { key: "Tab", bubbles: true }));
  ok(w0.d.activeElement === btn, "menu mobile: Tab depuis le dernier lien revient au bouton (focus piégé)");
  w0.d.dispatchEvent(new w0.w.KeyboardEvent("keydown", { key: "Escape", bubbles: true })); ok(btn.getAttribute("aria-expanded") === "false" && w0.d.activeElement === btn, "menu mobile: Échap ferme et rend le focus");
  ({ d } = await load("collections.html")); ok(d.querySelectorAll(".cr").length === 8, "collections: 8 créations");
  ok([...d.querySelectorAll(".cr .btn")].every(a => decodeURIComponent(a.href).includes(a.closest(".cr").querySelector("h3").textContent)), "collections: WhatsApp personnalisé par création");
  const g = await load("galerie.html"); ({ d } = g); const vis = () => [...d.querySelectorAll(".gi")].filter(x => !x.hidden).length;
  ok(vis() === 8 && d.getElementById("count").textContent.startsWith("8 créations"), "galerie: 8 créations + compteur");
  d.querySelector('[data-f="ceremonies"]').click(); ok(vis() === 2 && d.getElementById("count").textContent.startsWith("2 créations") && d.querySelector('[data-f="ceremonies"]').getAttribute("aria-pressed") === "true", "galerie: filtre Cérémonies (2) + compteur");
  d.querySelector('[data-f="costumes"]').click(); ok(vis() === 4, "galerie: filtre Costumes (4)");
  d.querySelector(".gi").click(); const lb = d.getElementById("lb"), cap = () => d.querySelector(".lb-t").textContent;
  ok(lb.hasAttribute("open") && cap().includes("1/4"), "visionneuse: ouverture"); ok(g.w.location.hash === "#costume-classique", "visionneuse: lien direct #id");
  lb.dispatchEvent(new g.w.KeyboardEvent("keydown", { key: "ArrowRight", bubbles: true })); ok(cap().includes("2/4"), "visionneuse: flèche droite");
  lb.dispatchEvent(new g.w.KeyboardEvent("keydown", { key: "ArrowLeft", bubbles: true })); lb.dispatchEvent(new g.w.KeyboardEvent("keydown", { key: "ArrowLeft", bubbles: true })); ok(cap().includes("4/4"), "visionneuse: boucle arrière");
  const box = d.querySelector(".lb-img"); box.dispatchEvent(Object.assign(new g.w.Event("pointerdown"), { clientX: 300 })); box.dispatchEvent(Object.assign(new g.w.Event("pointerup"), { clientX: 100 })); ok(cap().includes("1/4"), "visionneuse: balayage tactile");
  ok(decodeURIComponent(d.querySelector(".lb-wa").href).includes("Costume classique"), "visionneuse: WhatsApp personnalisé"); d.querySelector(".lb-x").click(); ok(!lb.hasAttribute("open"), "visionneuse: fermeture");
  const g2 = await load("galerie.html", { hash: "#robe-elegante" }); ok(g2.d.getElementById("lb").hasAttribute("open") && g2.d.querySelector(".lb-t").textContent.startsWith("Robe élégante"), "galerie: ouverture directe par lien #id");
  /* Contact */
  const post = status => ({ fetch: (u) => String(u).includes("csrf") ? Promise.resolve({ ok: true, json: () => Promise.resolve({ token: "tok" }) }) : Promise.resolve({ ok: status === 200, status, json: () => Promise.resolve(status === 200 ? { ok: true } : { ok: false }) }) });
  const c = await load("contact.html", { q: "?ref=robe-elegante", fetch: post(200).fetch }); ({ d } = c); const f = d.getElementById("f");
  ok(d.getElementById("ref").value === "Robe élégante", "contact: création de référence préremplie via ?ref=");
  f.dispatchEvent(new c.w.Event("submit", { cancelable: true })); await tick(20);
  ok(d.querySelectorAll("[aria-invalid=true]").length === 4 && d.activeElement.id === "nom", "contact: validation (4 erreurs, focus sur le premier champ)");
  Object.entries({ nom: "Awa K", tel: "+229 01 97 27 71 59", type: "Costume", besoin: "Un costume pour un mariage" }).forEach(([k, v]) => f.elements[k].value = v);
  d.getElementById("wa-send").click(); ok(c.w.opened.length === 1 && decodeURIComponent(c.w.opened[0]).includes("Nom : Awa K") && c.w.opened[0].startsWith("https://wa.me/2290197277159?text="), "contact: envoi par WhatsApp (récapitulatif)");
  ok(d.getElementById("csrf").value === "tok", "contact: jeton CSRF récupéré (réponse simulée)");
  f.dispatchEvent(new c.w.Event("submit", { cancelable: true })); await tick(30); ok(d.getElementById("status").textContent.includes("bien été envoyée"), "contact: succès (réponse serveur simulée)");
  const c2 = await load("contact.html", { fetch: post(503).fetch }); const f2 = c2.d.getElementById("f");
  Object.entries({ nom: "Awa K", tel: "0197277159", type: "Costume", besoin: "Un costume pour un mariage" }).forEach(([k, v]) => f2.elements[k].value = v);
  f2.dispatchEvent(new c2.w.Event("submit", { cancelable: true })); await tick(30); ok(c2.d.getElementById("status").textContent.includes("pas encore configuré"), "contact: serveur non configuré → message + WhatsApp");
  const c3 = await load("contact.html"); const f3 = c3.d.getElementById("f");
  Object.entries({ nom: "Awa K", tel: "0197277159", type: "Costume", besoin: "Un costume pour un mariage" }).forEach(([k, v]) => f3.elements[k].value = v);
  f3.dispatchEvent(new c3.w.Event("submit", { cancelable: true })); await tick(30); ok(c3.d.getElementById("status").textContent.includes("pas disponible"), "contact: sans PHP → message clair");
  console.log(fail ? `\n${fail} échec(s)` : "\nTous les tests passent"); process.exit(fail ? 1 : 0);
})();

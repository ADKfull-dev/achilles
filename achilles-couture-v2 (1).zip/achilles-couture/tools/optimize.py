"""Optimise les photos : python3 tools/optimize.py  (requiert Pillow : pip install pillow)
Lit /photos-originales, écrit assets/img/photos/<nom>-480|800|1200|1800.webp (jamais agrandi au-delà de l'original)."""
import pathlib
from PIL import Image, ImageOps
R = pathlib.Path(__file__).resolve().parent.parent
(R/"assets/img/photos").mkdir(parents=True, exist_ok=True)
for f in sorted((R/"photos-originales").iterdir()):
    if f.suffix.lower() not in (".jpg", ".jpeg", ".png", ".webp"): continue
    im = ImageOps.exif_transpose(Image.open(f)).convert("RGB")
    for w in (480, 800, 1200, 1800):
        t = im if im.width <= w else im.resize((w, round(im.height * w / im.width)), Image.LANCZOS)
        t.save(R/f"assets/img/photos/{f.stem}-{w}.webp", "WEBP", quality=82, method=6)
    print("OK", f.name, f"({im.width}x{im.height})")
